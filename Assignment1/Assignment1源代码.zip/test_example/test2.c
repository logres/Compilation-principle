int main()
{
    float a[10][2];
    int i;
    a[5,3] = 1.5;
    if (a[1][2] == 0) i = 1 else i = 0;
}