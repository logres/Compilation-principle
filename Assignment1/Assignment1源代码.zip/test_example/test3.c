int inc()
{
    int i;
    i = i + 1;
}
