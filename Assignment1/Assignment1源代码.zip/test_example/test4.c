struct Complex
{
float real, image;
};
int main()
{
struct Complex x;
y.image = 3.5;
}
